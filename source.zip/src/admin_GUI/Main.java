package admin_GUI;
/**
 * The driver for the Guten Search Software
 * @author Team 11
 *
 */
public class Main {
  private final static MainFrame mainframe = new MainFrame();
  public static void main(String[] args) {
    new Add_Text(mainframe);
  }
}
  